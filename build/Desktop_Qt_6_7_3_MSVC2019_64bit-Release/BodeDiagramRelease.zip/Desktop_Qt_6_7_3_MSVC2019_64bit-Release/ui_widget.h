/********************************************************************************
** Form generated from reading UI file 'widget.ui'
**
** Created by: Qt User Interface Compiler version 6.7.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_WIDGET_H
#define UI_WIDGET_H

#include <QtCharts/QChartView>
#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QFrame>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Widget
{
public:
    QFrame *frame;
    QHBoxLayout *horizontalLayout_3;
    QGroupBox *groupBox_3;
    QVBoxLayout *verticalLayout_4;
    QHBoxLayout *horizontalLayout;
    QPushButton *exportButton;
    QFrame *frame_2;
    QHBoxLayout *horizontalLayout_2;
    QPushButton *clearButton;
    QGroupBox *groupBox;
    QVBoxLayout *verticalLayout_2;
    QGridLayout *gridLayout;
    QLineEdit *numeratorLineEdit;
    QLineEdit *frequencyMinlineEdit;
    QLabel *label_2;
    QLabel *label_4;
    QPushButton *calculatePushButton;
    QLineEdit *denominatorLineEdit;
    QLineEdit *sigmaLineEdit;
    QLabel *label_3;
    QLabel *label_5;
    QLabel *label;
    QLineEdit *frequencyMaxlineEdit;
    QFrame *frame_3;
    QVBoxLayout *verticalLayout_6;
    QGroupBox *groupBox_4;
    QHBoxLayout *horizontalLayout_4;
    QChartView *magnitudeGraphicView;
    QChartView *phaseGraphicView;
    QFrame *frame_4;
    QVBoxLayout *verticalLayout_5;
    QGroupBox *groupBox_2;
    QVBoxLayout *verticalLayout_3;
    QVBoxLayout *verticalLayout;
    QLabel *label_6;
    QTextEdit *printText;
    QLabel *label_7;
    QTextEdit *printTextIsStable;

    void setupUi(QWidget *Widget)
    {
        if (Widget->objectName().isEmpty())
            Widget->setObjectName("Widget");
        Widget->resize(954, 731);
        frame = new QFrame(Widget);
        frame->setObjectName("frame");
        frame->setGeometry(QRect(10, 570, 501, 121));
        frame->setFrameShape(QFrame::Shape::StyledPanel);
        frame->setFrameShadow(QFrame::Shadow::Raised);
        horizontalLayout_3 = new QHBoxLayout(frame);
        horizontalLayout_3->setObjectName("horizontalLayout_3");
        groupBox_3 = new QGroupBox(frame);
        groupBox_3->setObjectName("groupBox_3");
        verticalLayout_4 = new QVBoxLayout(groupBox_3);
        verticalLayout_4->setObjectName("verticalLayout_4");
        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName("horizontalLayout");
        exportButton = new QPushButton(groupBox_3);
        exportButton->setObjectName("exportButton");

        horizontalLayout->addWidget(exportButton);


        verticalLayout_4->addLayout(horizontalLayout);


        horizontalLayout_3->addWidget(groupBox_3);

        frame_2 = new QFrame(Widget);
        frame_2->setObjectName("frame_2");
        frame_2->setGeometry(QRect(10, 330, 501, 241));
        frame_2->setFrameShape(QFrame::Shape::StyledPanel);
        frame_2->setFrameShadow(QFrame::Shadow::Raised);
        horizontalLayout_2 = new QHBoxLayout(frame_2);
        horizontalLayout_2->setObjectName("horizontalLayout_2");
        clearButton = new QPushButton(frame_2);
        clearButton->setObjectName("clearButton");

        horizontalLayout_2->addWidget(clearButton);

        groupBox = new QGroupBox(frame_2);
        groupBox->setObjectName("groupBox");
        verticalLayout_2 = new QVBoxLayout(groupBox);
        verticalLayout_2->setObjectName("verticalLayout_2");
        gridLayout = new QGridLayout();
        gridLayout->setObjectName("gridLayout");
        numeratorLineEdit = new QLineEdit(groupBox);
        numeratorLineEdit->setObjectName("numeratorLineEdit");
        numeratorLineEdit->setClearButtonEnabled(true);

        gridLayout->addWidget(numeratorLineEdit, 0, 2, 1, 3);

        frequencyMinlineEdit = new QLineEdit(groupBox);
        frequencyMinlineEdit->setObjectName("frequencyMinlineEdit");
        frequencyMinlineEdit->setClearButtonEnabled(true);

        gridLayout->addWidget(frequencyMinlineEdit, 3, 1, 1, 2);

        label_2 = new QLabel(groupBox);
        label_2->setObjectName("label_2");

        gridLayout->addWidget(label_2, 2, 0, 1, 2);

        label_4 = new QLabel(groupBox);
        label_4->setObjectName("label_4");

        gridLayout->addWidget(label_4, 3, 3, 1, 1);

        calculatePushButton = new QPushButton(groupBox);
        calculatePushButton->setObjectName("calculatePushButton");

        gridLayout->addWidget(calculatePushButton, 4, 0, 1, 5);

        denominatorLineEdit = new QLineEdit(groupBox);
        denominatorLineEdit->setObjectName("denominatorLineEdit");
        denominatorLineEdit->setClearButtonEnabled(true);

        gridLayout->addWidget(denominatorLineEdit, 1, 2, 1, 3);

        sigmaLineEdit = new QLineEdit(groupBox);
        sigmaLineEdit->setObjectName("sigmaLineEdit");
        sigmaLineEdit->setClearButtonEnabled(true);

        gridLayout->addWidget(sigmaLineEdit, 2, 2, 1, 2);

        label_3 = new QLabel(groupBox);
        label_3->setObjectName("label_3");

        gridLayout->addWidget(label_3, 3, 0, 1, 1);

        label_5 = new QLabel(groupBox);
        label_5->setObjectName("label_5");

        gridLayout->addWidget(label_5, 1, 0, 1, 1);

        label = new QLabel(groupBox);
        label->setObjectName("label");

        gridLayout->addWidget(label, 0, 0, 1, 2);

        frequencyMaxlineEdit = new QLineEdit(groupBox);
        frequencyMaxlineEdit->setObjectName("frequencyMaxlineEdit");
        frequencyMaxlineEdit->setClearButtonEnabled(true);

        gridLayout->addWidget(frequencyMaxlineEdit, 3, 4, 1, 1);


        verticalLayout_2->addLayout(gridLayout);


        horizontalLayout_2->addWidget(groupBox);

        frame_3 = new QFrame(Widget);
        frame_3->setObjectName("frame_3");
        frame_3->setGeometry(QRect(10, 10, 931, 321));
        frame_3->setFrameShape(QFrame::Shape::StyledPanel);
        frame_3->setFrameShadow(QFrame::Shadow::Raised);
        verticalLayout_6 = new QVBoxLayout(frame_3);
        verticalLayout_6->setObjectName("verticalLayout_6");
        groupBox_4 = new QGroupBox(frame_3);
        groupBox_4->setObjectName("groupBox_4");
        horizontalLayout_4 = new QHBoxLayout(groupBox_4);
        horizontalLayout_4->setObjectName("horizontalLayout_4");
        magnitudeGraphicView = new QChartView(groupBox_4);
        magnitudeGraphicView->setObjectName("magnitudeGraphicView");

        horizontalLayout_4->addWidget(magnitudeGraphicView);

        phaseGraphicView = new QChartView(groupBox_4);
        phaseGraphicView->setObjectName("phaseGraphicView");

        horizontalLayout_4->addWidget(phaseGraphicView);


        verticalLayout_6->addWidget(groupBox_4);

        frame_4 = new QFrame(Widget);
        frame_4->setObjectName("frame_4");
        frame_4->setGeometry(QRect(520, 330, 421, 361));
        frame_4->setFrameShape(QFrame::Shape::StyledPanel);
        frame_4->setFrameShadow(QFrame::Shadow::Raised);
        verticalLayout_5 = new QVBoxLayout(frame_4);
        verticalLayout_5->setObjectName("verticalLayout_5");
        groupBox_2 = new QGroupBox(frame_4);
        groupBox_2->setObjectName("groupBox_2");
        verticalLayout_3 = new QVBoxLayout(groupBox_2);
        verticalLayout_3->setObjectName("verticalLayout_3");
        verticalLayout = new QVBoxLayout();
        verticalLayout->setObjectName("verticalLayout");
        label_6 = new QLabel(groupBox_2);
        label_6->setObjectName("label_6");

        verticalLayout->addWidget(label_6);

        printText = new QTextEdit(groupBox_2);
        printText->setObjectName("printText");

        verticalLayout->addWidget(printText);

        label_7 = new QLabel(groupBox_2);
        label_7->setObjectName("label_7");

        verticalLayout->addWidget(label_7);

        printTextIsStable = new QTextEdit(groupBox_2);
        printTextIsStable->setObjectName("printTextIsStable");

        verticalLayout->addWidget(printTextIsStable);


        verticalLayout_3->addLayout(verticalLayout);


        verticalLayout_5->addWidget(groupBox_2);


        retranslateUi(Widget);

        QMetaObject::connectSlotsByName(Widget);
    } // setupUi

    void retranslateUi(QWidget *Widget)
    {
        Widget->setWindowTitle(QCoreApplication::translate("Widget", "Widget", nullptr));
        groupBox_3->setTitle(QCoreApplication::translate("Widget", "Export Graphics In .Pdf Format", nullptr));
        exportButton->setText(QCoreApplication::translate("Widget", " Export", nullptr));
        clearButton->setText(QCoreApplication::translate("Widget", "Clear", nullptr));
        groupBox->setTitle(QCoreApplication::translate("Widget", "Transfer Function", nullptr));
        numeratorLineEdit->setText(QCoreApplication::translate("Widget", "s^2-3", nullptr));
        frequencyMinlineEdit->setText(QCoreApplication::translate("Widget", "0.1", nullptr));
        label_2->setText(QCoreApplication::translate("Widget", "Sigma \317\203 :", nullptr));
        label_4->setText(QCoreApplication::translate("Widget", "Frequency Max(Hz):", nullptr));
        calculatePushButton->setText(QCoreApplication::translate("Widget", "Calculate", nullptr));
        denominatorLineEdit->setText(QCoreApplication::translate("Widget", "-s^3-s+1", nullptr));
        denominatorLineEdit->setPlaceholderText(QString());
        sigmaLineEdit->setText(QCoreApplication::translate("Widget", "0", nullptr));
        label_3->setText(QCoreApplication::translate("Widget", "Frequency Min (Hz):", nullptr));
        label_5->setText(QCoreApplication::translate("Widget", "Denominator D(s):", nullptr));
        label->setText(QCoreApplication::translate("Widget", " Numerator N(s):", nullptr));
        frequencyMaxlineEdit->setText(QCoreApplication::translate("Widget", "10", nullptr));
        groupBox_4->setTitle(QCoreApplication::translate("Widget", "Bode Diagram", nullptr));
        groupBox_2->setTitle(QCoreApplication::translate("Widget", "Results", nullptr));
        label_6->setText(QCoreApplication::translate("Widget", "Zeros and Poles :", nullptr));
        label_7->setText(QCoreApplication::translate("Widget", "Stability :", nullptr));
    } // retranslateUi

};

namespace Ui {
    class Widget: public Ui_Widget {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_WIDGET_H
